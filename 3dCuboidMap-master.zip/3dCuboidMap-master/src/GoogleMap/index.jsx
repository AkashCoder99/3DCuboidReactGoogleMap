import React, { useRef } from "react";
import GoogleMapReact from "google-map-react";
import html2canvas from "html2canvas";

const AnyReactComponent = ({ text }) => <div>{text}</div>;

const GoogleMap = ({ setImage }) => {
  const ref = useRef(null);
  const defaultProps = {
    center: {
      lat: 10.99835602,
      lng: 77.01502627,
    },
    zoom: 11,
  };

  const capture = async () => {
    const canvas = await html2canvas(ref.current, { useCORS: true });
    const image = canvas?.toDataURL();
    setImage(image);
  };

  return (
    <div ref={ref}>
      <div style={{ height: "90vh", width: "100%" }}>
        <GoogleMapReact
          bootstrapURLKeys={{
            key: "AIzaSyDd33r3mvrGV-mR90R8yUWqUgDVaGb1Axs",
            language: "en",
          }}
          defaultCenter={defaultProps.center}
          defaultZoom={defaultProps.zoom}
        >
          <AnyReactComponent lat={59.955413} lng={30.337844} text="My Marker" />
        </GoogleMapReact>
      </div>
      <button
        onClick={capture}
        style={{
          padding: "10px",
          margin: "10px",
        }}
      >
        Click
      </button>
    </div>
  );
};

export default GoogleMap;
