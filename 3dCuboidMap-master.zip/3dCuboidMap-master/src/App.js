import "./App.css";
import GoogleMap from "./GoogleMap";
import Cuboid from "./Cuboid/Cuboid";
import { useState } from "react";

function App() {
  const [image, setImage] = useState("");
  return (
    <div className="App">
      <GoogleMap setImage={setImage} />
      <Cuboid image={image} />
    </div>
  );
}

export default App;
